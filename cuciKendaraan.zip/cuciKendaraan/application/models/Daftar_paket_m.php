<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Daftar_paket_m extends CI_Model {

	public function get($id = null){
		$this->db->select('*');
		$this->db->from('daftar_paket');
		if($id != null) {
			$this->db->where('id_paket', $id);
		}
		$query = $this->db->get();
		return $query;
	}

	public function tambah($post){
		$data = [
			'nama_paket' => $post['nama_paket'],
			'harga' => $post['harga']
		];
		$this->db->insert('daftar_paket',$data);	
	}

	public function hapus($id,$tabel){
		$this->db->where($id);
		$this->db->delete($tabel);
	}

	public function edit($id,$tabel,$post){
		$data = [
			'nama_paket' => $post['nama_paket'],
			'harga' => $post['harga']
		];
		$this->db->where($id);
		$this->db->update($tabel,$data);
		
	}

	public function proses_cuci($id,$tabel){
		$data = [
			'status' =>  'Sedang dicuci'
		];
		$this->db->where($id);
		$this->db->update($tabel,$data);
		
	}


}
