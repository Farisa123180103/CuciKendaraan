<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ganti_pw_m extends CI_Model {

	
	public function edit($id,$tabel,$post){
		$data = [
			'password' => $post['baru']
		];
		$this->db->where($id);
		$this->db->update($tabel,$data);
		
	}

	public function cek($post){
		$this->db->select('*');
		$this->db->from('user');
		$this->db->where('password',$post['lama']);
		$query = $this->db->get();
		return $query;
	}

}
