<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan_m extends CI_Model {

	public function login($post){
		$this->db->select('*');
		$this->db->from('user');
		$this->db->where('username',$post['uname']);
		$this->db->where('password',$post['pw']);
		$query = $this->db->get();
		return $query;
	}

	public function get($id = null){
		$this->db->select('*');
		$this->db->from('user');
		if($id != null) {
			$this->db->where('user_id', $id);
		}
		$query = $this->db->get();
		return $query;
	}

	// public function lihat($post){
	// 	$dari = $post['dari'];
	// 	$sampai = $post['sampai'];
	// 	$this->db->select('*');
	// 	$this->db->from('transaksi');
	// 	$this->db->join('data_antri','data_antri.id_data=transaksi.id_data');
	// 	$this->db->join('daftar_paket','data_antri.id_paket=daftar_paket.id_paket');
	// 	$this->db->where('tgl>=',$dari);
	// 	$this->db->where('tgl<=',$sampai);
	// 	$query = $this->db->get();
	// 	return $query;
	// }

	// public function hitung($post){
	// 	$dari = $post['dari'];
	// 	$sampai = $post['sampai'];
	// 	$this->db->select_sum('harga');
	// 	$this->db->from('daftar_paket');
	// 	$this->db->join('data_antri','data_antri.id_paket=daftar_paket.id_paket');
	// 	$this->db->join('transaksi','data_antri.id_data=transaksi.id_data');
	// 	$this->db->where('tgl>=',$dari);
	// 	$this->db->where('tgl<=',$sampai);
	// 	$query = $this->db->get();
	// 	if($query->num_rows()>0){
	// 		return $query->row()->harga;
	// 	}else{
	// 		return 0;
	// 	}
		
	// }

	public function lihat($dari,$sampai){
		$this->db->select('*');
		$this->db->from('transaksi');
		$this->db->join('data_antri','data_antri.id_data=transaksi.id_data');
		$this->db->join('daftar_paket','data_antri.id_paket=daftar_paket.id_paket');
		$this->db->where('tgl>=',$dari);
		$this->db->where('tgl<=',$sampai);
		$query = $this->db->get();
		return $query;
	}

	public function hitung($dari,$sampai){
		$this->db->select_sum('harga');
		$this->db->from('daftar_paket');
		$this->db->join('data_antri','data_antri.id_paket=daftar_paket.id_paket');
		$this->db->join('transaksi','data_antri.id_data=transaksi.id_data');
		$this->db->where('tgl>=',$dari);
		$this->db->where('tgl<=',$sampai);
		$query = $this->db->get();
		if($query->num_rows()>0){
			return $query->row()->harga;
		}else{
			return 0;
		}
		
	}
}

