<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi_m extends CI_Model {

	public function buat_kode(){
		$this->db->select('RIGHT(transaksi.id_transaksi,4) as kode', FALSE);
		  $this->db->order_by('id_transaksi','DESC');    
		  $this->db->limit(1);    
		  $query = $this->db->get('transaksi');      //cek dulu apakah ada sudah ada kode di tabel.    
		  if($query->num_rows() <> 0){      
		   //jika kode ternyata sudah ada.      
		   $data = $query->row();      
		   $kode = intval($data->kode) + 1;    
		  }
		  else {      
		   //jika kode belum ada      
		   $kode = 1;    
		  }

		  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT); // angka 4 menunjukkan jumlah digit angka 0
		  $kodejadi = "CUS-".$kodemax;    // hasilnya ODJ-9921-0001 dst.
		  return $kodejadi;
	}

	public function apa($id){
		$this->db->select('*');
		$this->db->from('data_antri');
		$this->db->join('daftar_paket','data_antri.id_paket=daftar_paket.id_paket');
		$this->db->where($id);
		$query = $this->db->get();
		return $query;
	}

	

	public function tambah($post,$id){
		$data = [
			'id_transaksi' => $post['nota'],
			'id_data' => $id,
			'tgl' => $post['tgl'],
			'bayar' => $post['bayar'],
			'kembalian' =>  $post['kembalian']
		];
		$this->db->insert('transaksi',$data);	
	}

	public function proses_selesai($id){
		$data = [
			'status' =>  'Selesai'
		];
		$this->db->where($id);
		$this->db->update('data_antri',$data);
		
	}


}
