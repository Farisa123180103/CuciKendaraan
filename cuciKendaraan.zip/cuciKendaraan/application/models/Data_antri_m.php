<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_antri_m extends CI_Model {

	public function get($id = null){
		$this->db->select('*');
		$this->db->from('data_antri');
		if($id != null) {
			$this->db->where('id_data', $id);
		}
		$query = $this->db->get();
		return $query;
	}

	public function tambah($post){
		$data = [
			'nama_pelanggan' => $post['nama_p'],
			'id_paket' => $post['paket'],
			'no_pol' => $post['no_pol'],
			'status' => "antri",
			'user_id' =>  $post['user']
		];
		$this->db->insert('data_antri',$data);	
	}

	public function hapus($id,$tabel){
		$this->db->where($id);
		$this->db->delete($tabel);
	}

	public function edit($id,$tabel,$post){
		$data = [
			'nama_pelanggan' => $post['nama'],
			'id_paket' => $post['paket'],
			'no_pol' => $post['no_pol'],
			'user_id' =>  $post['user']
		];
		$this->db->where($id);
		$this->db->update($tabel,$data);
		
	}

	public function proses_cuci($id,$tabel){
		$data = [
			'status' =>  'Sedang dicuci'
		];
		$this->db->where($id);
		$this->db->update($tabel,$data);
		
	}


}
