<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_m extends CI_Model {

	public function login($post){
		$this->db->select('*');
		$this->db->from('user');
		$this->db->where('username',$post['uname']);
		$this->db->where('password',$post['pw']);
		$query = $this->db->get();
		return $query;
	}

	public function get($id = null){
		$this->db->select('*');
		$this->db->from('user');
		if($id != null) {
			$this->db->where('user_id', $id);
		}
		$query = $this->db->get();
		return $query;
	}

	public function tambah($post){
		$data = [
			'username' => $post['uname'],
			'password' =>  $post['pw'],
			'nama' =>  $post['nama'],
			'no_telp' =>  $post['telp'],
			'role_id' =>  $post['role_id']
		];
		$this->db->insert('user',$data);	
	}

	public function hapus($id,$tabel){
		$this->db->where($id);
		$this->db->delete($tabel);
	}

	public function edit($id,$tabel,$post){
		$data = [
			'username' => $post['uname'],
			'password' =>  $post['pw'],
			'nama' =>  $post['nama'],
			'no_telp' =>  $post['telp'],
			'role_id' =>  $post['role_id']
		];
		$this->db->where($id);
		$this->db->update($tabel,$data);
		
	}

}
