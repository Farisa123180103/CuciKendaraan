<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Daftar_paket extends CI_Controller {

	function __construct(){
		parent::__construct();
		check_nologin();		
		$this->load->model('daftar_paket_m');
		$this->load->helper('url');
 
	}

	public function index()
	{
		
		// $this->load->model('daftar_paket_m');
		$data['row'] = $this->daftar_paket_m->get();
		$this->template->load('template','daftar_paket');
	}

	public function tambah(){
		$post = $this->input->post(null, TRUE);
		$this->daftar_paket_m->tambah($post);
		
		$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert">Daftar Paket Berhasil ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
    	redirect('daftar_paket');

	}

	public function hapus($id){
		$where = array('id_paket' => $id);
		$this->daftar_paket_m->hapus($where,'daftar_paket');
		$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert"> Data Berhasil dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
		redirect('daftar_paket');

	}

	public function edit($id){
		$where = array('id_paket' => $id);
		$post = $this->input->post(null, TRUE);
		$this->daftar_paket_m->edit($where,'daftar_paket',$post);
		$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert"> Data Berhasil diedit <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
		redirect('daftar_paket');
	}

}
