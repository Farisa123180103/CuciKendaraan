<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {


	public function index()
	{
		$this->load->model('user_m');
		$this->load->view('register');
	}

	public function tambah_user(){
		$post = $this->input->post(null, TRUE);
		$this->user_m->tambah($post);
		
		echo "<script>
				alert('Register berhasil');
				window.location='".base_url('auth/login')."';
			</script>";

	}
}
