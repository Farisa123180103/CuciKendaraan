<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data_antri extends CI_Controller {

	function __construct(){
		parent::__construct();
		check_nologin();		
		$this->load->model('data_antri_m');
		$this->load->helper('url');
		
 
	}

	public function index()
	{
		
		$this->load->model('transaksi_m');
		$data['kode'] = $this->transaksi_m->buat_kode();
		$this->template->load('template','data_antri',$data);
	}

	public function tambah(){
		$post = $this->input->post(null, TRUE);
		$this->data_antri_m->tambah($post);
		
		$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert"> Daftar Antri Berhasil ditambahkan <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
    	redirect('data_antri');

	}

	public function hapus($id){
		$where = array('id_data' => $id);
		$this->data_antri_m->hapus($where,'data_antri');
		$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert"> Data Berhasil dihapus <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
		redirect('data_antri');

	}

	public function edit($id){
		$where = array('id_data' => $id);
		$post = $this->input->post(null, TRUE);
		$this->data_antri_m->edit($where,'data_antri',$post);
		$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert"> Data Berhasil diedit <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
		redirect('data_antri');
	}

	public function proses($id)
	{
		$where = array('id_data' => $id);
		$this->data_antri_m->proses_cuci($where,'data_antri');
		$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert"> Verifikasi Proses Antrian Berhasil <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
		redirect('data_antri');
	}

}
