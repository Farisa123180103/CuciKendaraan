<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

	function __construct(){
		parent::__construct();
		check_nologin();
		$this->load->library('pagination');		
		$this->load->model('transaksi_m');
		$this->load->helper('url');
	}

	public function index()
	{
		
		$this->template->load('template','transaksi');
	}

	public function tambah($id){
		$where = array('id_data' => $id);
		$post = $this->input->post(null, TRUE);
		$this->transaksi_m->tambah($post,$id);
		$this->transaksi_m->proses_selesai($where);
		$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert"> Transaksi Berhasil <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
    	redirect('transaksi');

	}

	public function input($id)
	{
		$where = array('id_data' => $id);
		$data['row'] = $this->transaksi_m->apa($where)->result();
		$data['kode'] = $this->transaksi_m->buat_kode();
		$this->template->load('template','transaksi_tambah',$data);
	}

	



}
