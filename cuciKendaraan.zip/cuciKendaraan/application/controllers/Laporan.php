<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

	function __construct(){
		parent::__construct();
		check_nologin();		
		$this->load->model('laporan_m');
		$this->load->helper('url');
 
	}

	public function index()
	{
		
		$this->template->load('template','laporan');
	}

	public function lihat_laporan(){
		$post = $this->input->post(null, TRUE);
		$dari = $post['dari'];
		$sampai = $post['sampai'];
		$data['row'] = $this->laporan_m->lihat($dari,$sampai)->result();
		$data['jumlah'] = $this->laporan_m->hitung($dari,$sampai);
		$data['dari']  = $post['dari'];
		$data['sampai']  = $post['sampai'];
		// $data['row'] = $this->laporan_m->lihat($post)->result();
		// $data['jumlah'] = $this->laporan_m->hitung($post);
		$this->template->load('template','laporan_cetak',$data);
		// $this->view->load('print_cetak',$data);

	}

	public function print($dari,$sampai){
		$data['row'] = $this->laporan_m->lihat($dari,$sampai)->result();
		$data['jumlah'] = $this->laporan_m->hitung($dari,$sampai);
		$this->template->load('template','print_laporan',$data);
		// $this->load->view('print_laporan',$data);
	}
}