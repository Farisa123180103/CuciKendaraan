<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ganti_pw extends CI_Controller {

	function __construct(){
		parent::__construct();
		check_nologin();		
		$this->load->model('ganti_pw_m');
		$this->load->helper('url');
		
 
	}

	public function index()
	{
		$this->template->load('template','ganti_pw');
	}
	public function edit($id){
		$post = $this->input->post(null, TRUE);
		$query = $this->ganti_pw_m->cek($post);
			if($query->num_rows() > 0){
				//row di extrak cuman 1 baris, result semua
				if ($post['baru']==$post['ulang']) {
					$where = array('user_id' => $id);
				$this->ganti_pw_m->edit($where,'user',$post);
				echo "<script>
						alert('Password Berhasil Diganti');
						window.location='".base_url('ganti_pw')."';
					</script>";
				} else{
					echo "<script>
						alert('Password Baru dan Confirmasi Password Baru berbeda');
						window.location='".base_url('ganti_pw')."';
					</script>";
				}
			} else{
				echo "<script>
						alert('Password Lama Salah');
						window.location='".base_url('ganti_pw')."';
					</script>";
			}
		
	}

}
