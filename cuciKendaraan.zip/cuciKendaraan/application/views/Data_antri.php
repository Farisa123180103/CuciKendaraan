<section class="page-section about-heading">
    <div class="container">
      <img class="img-fluid rounded about-heading-img mb-3 mb-lg-0" src="<?=base_url()?>asset/img/about.jpg" alt="">
      <div class="about-heading-content">
        <div class="row">
          <div class="col-xl-11 col-lg-10 mx-auto">
            <div class="bg-faded rounded p-5">
              <h2 class="section-heading mb-4">
                <span class="section-heading-upper">Cuci Kendaraan Legundi</span>
                <span class="section-heading-lower">Daftar Antri</span>
              </h2>
              <div class="pull-right">
                <a data-toggle="modal" data-target="#tambah-data" class="btn btn-primary btn-flat">Create</a>
              </div>
              <div class="box-body table-responsive">
                <table class="table table-bordered table-striped table-hover">
                  <thead>
                    <tr class="bg-info">
                      <th>No.Antrian</th>
                      <th>Nama</th>
                      <th>Paket</th>
                      <th>No.Polisi</th>
                      <?php if($this->data->user_masuk()->role_id==1 ) { ?>
                      <th>Status</th><?php } ?>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    if($this->data->user_masuk()->role_id==2 ) {
                    $no=1;
                    $row = $this->db->query('SELECT * FROM data_antri d, daftar_paket p WHERE d.id_paket=p.id_paket and d.status="antri" ');
                    foreach($row->result() as $key => $data ) { ?>
                    <tr>
                      <th><?=$no++?></th>
                      <th><?=ucfirst($data->nama_pelanggan)?></th>
                      <th><?=$data->nama_paket?>-Rp.<?=$data->harga?></th>
                      <th><?=$data->no_pol?></th>
                      <th>
                        <center>
                          <div>
                            <?php if($data->user_id==$this->data->user_masuk()->user_id){ ?>
                            <a data-toggle="modal" data-target="#modal-edit<?=$data->id_data;?>" class="btn btn-warning" data-popup="tooltip" data-placement="top" title="Edit Data"><i class="fs fa-pencil"></i>edit</a>
                            <a href="<?= base_url('data_antri/hapus/'.$data->id_data); ?>" onclick="return confirm('Apakah Anda Ingin Cancel <?=$data->nama_pelanggan;?> ?');" class="btn btn-danger" data-popup="tooltip" data-placement="top" title="Hapus Data"><i class="fs fa-trash"></i>hapus</a>
                          </div>
                        </center>
                      </th>
                    </tr>
                    <?php }} 
                    } else {
                    $no=1;
                    $row = $this->db->query('SELECT * FROM data_antri d, daftar_paket p WHERE d.id_paket=p.id_paket and d.status!="selesai" ');
                    foreach($row->result() as $key => $data ) { ?>
                    <tr>
                      <th><?=$no++?></th>
                      <th><?=ucfirst($data->nama_pelanggan)?></th>
                      <th><?=$data->nama_paket?>-Rp.<?=$data->harga?></th>
                      <th><?=$data->no_pol?></th>
                      <th><?=$data->status?></th>
                      <th>
                        <center>
                          <div>
                            <a data-toggle="modal" data-target="#modal-edit<?=$data->id_data;?>" class="btn btn-warning" data-popup="tooltip" data-placement="top" title="Edit Data"><i class="fs fa-pencil"></i>edit</a>
                            <a href="<?= base_url('data_antri/hapus/'.$data->id_data); ?>" onclick="return confirm('Apakah Anda Ingin Cancel <?=$data->nama_pelanggan;?> ?');" class="btn btn-danger" data-popup="tooltip" data-placement="top" title="Hapus Data"><i class="fs fa-trash"></i>hapus</a>
                          <a href="<?=base_url('data_antri/proses/'.$data->id_data);?>" class="btn btn-warning" data-popup="tooltip" data-placement="top" title="proses"><i class="fs fa-pencil"></i>Proses</a>
                           <a href="<?=base_url('transaksi/input/'.$data->id_data);?>" class="btn btn-warning" data-popup="tooltip" data-placement="top" title="Transaksi Data"><i class="fs fa-pencil"></i>Transaksi</a>
                          </div>
                        </center>
                      </th>
                    </tr>
                    <?php }} ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

   <!-- Modal Tambah -->
     <div aria-hidden="true" aria-labelledby="myModalLabel"  id="tambah-data" class="modal fade">
         <div class="modal-dialog">
             <div class="modal-content">
                 <div class="modal-header bg-primary">
                     <h4 class="modal-title">Tambah Data</h4>
                     <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                     
                 </div>
                 <form class="form-horizontal" action="<?php echo base_url('data_antri/tambah')?>" method="post" enctype="multipart/form-data" role="form">
                      <div class="modal-body">
                        <input type="hidden" readonly value="<?=$this->data->user_masuk()->user_id;?>" name="user" class="form-control" >
                          <div class="form-group">
                              <label>Nama Pelanggan</label>
                                <?php if($this->session->userdata('role_id') == 2 ) { ?>
                                  <input type="text" class="form-control" readonly="" name="nama_p" value="<?= ucfirst($this->data->user_masuk()->nama) ?>" required>
                                <?php } else{ ?>
                                  <input type="text" class="form-control"  name="nama_p" placeholder="Tuliskan Nama Pelanggan" required>
                                <?php }?>
                          </div>
                          <div class="form-group">
                              <label>Paket</label>
                               <select class="form-control" name="paket" id="paket" onchange="changeValuePaket(this.value)">
                                  <option disabled="" selected="">---Pilih Paket---</option>
                                  <?php
                                  $username = $this->db->query('SELECT * FROM daftar_paket');
                                  foreach ($username->result() as $d) { 
                                  ?>
                                    <option value="<?=$d->id_paket;?>"><?=$d->nama_paket;?>-Rp.<?=$d->harga;?></option>
                                  <?php }?>
                                </select>
                          </div>
                          <div class="form-group">
                              <label>No.Polisi</label>
                               <input class="form-control" name="no_pol" placeholder="Tuliskan No.Polisi">
                          </div>
                      <div class="modal-footer">
                          <button class="btn btn-info" name="simpan" type="submit"> Kirim</button>
                          <button type="button" class="btn btn-warning" data-dismiss="modal"> Batal</button>
                      </div>
                    </div>
                  </form>
              </div>
           </div>
       </div>
    </div>
     <!-- END Modal Tambah -->
     <!-- Model Edit Data-->
     <?php 
     $row = $this->db->query('SELECT * FROM data_antri d JOIN daftar_paket p WHERE d.id_paket=p.id_paket');
     foreach($row->result() as $key => $data ) {?>
      <div class="row">
        <div id="modal-edit<?=$data->id_data;?>" class="modal fade">
          <div class="modal-dialog">
            <form action="<?= base_url('data_antri/edit/'.$data->id_data); ?>" method="post" class="form-horizontal" enctype="multipart/form-data" role="form">
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <h4 class="modal-title">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <div class="modal-body">
       
                <input type="hidden" readonly value="<?=$data->id_data;?>" name="id_data"  class="form-control" >

                <input type="hidden" readonly value="<?=$this->data->user_masuk()->user_id;?>" name="user" class="form-control" >

                <div class="form-group">
                    <label>Nama Pelanggan</label>
                        <input type="text" class="form-control" name="nama" autocomplete="off" value="<?=$data->nama_pelanggan;?>" placeholder="Tuliskan Nama Pelanggan" required>
                </div>
                <div class="form-group">
                    <label>Paket</label>
                     <select name="paket" class="form-control">
                        <?php
                        $query = $this->db->query('SELECT * FROM daftar_paket');
                        foreach ($query->result() as $key => $d) {
                          if($data->id_paket==$d->id_paket){
                            $select="selected";
                          } else {
                            $select="";
                          }
                          echo "<option $select value='$d->id_paket'>".$d->nama_paket."-Rp.".$d->harga."</option>";
                        }
                        ?>
                      </select>
                </div>
                <div class="form-group">
                    <label>No.Polisi</label>
                     <input class="form-control" name="no_pol" autocomplete="off" value="<?=$data->no_pol;?>"  placeholder="Tuliskan No.Polisi">
                </div>
                <div class="modal-footer">
                    <button class="btn btn-info" name="edit" type="submit"> Edit </button>
                    <button type="button" class="btn btn-warning" data-dismiss="modal"> Batal</button>
                </div>
              </div>
            </div>
            </form>
          </div>
        </div>
      </div>
      <?php } ?>
     <!--END Model Edit-->