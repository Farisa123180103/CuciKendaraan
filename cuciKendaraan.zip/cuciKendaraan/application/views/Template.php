<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Aplikasi Cuci Kendaraan Legundi</title>

  <!-- Bootstrap core CSS -->
  <link href="<?=base_url()?>asset/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?=base_url()?>asset/css/business-casual.min.css" rel="stylesheet">

</head>

<body>

  <h1 class="site-heading text-center text-white d-none d-lg-block">
    <span class="site-heading-upper text-primary mb-3">Cuci Kendaraan Legundi</span>
    <span class="site-heading-lower">Selamat Datang, <?= ucfirst($this->data->user_masuk()->nama) ?> !!!</span>
  </h1>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark py-lg-4" id="mainNav">
    <div class="container">
      <a class="navbar-brand text-uppercase text-expanded font-weight-bold d-lg-none" href="#">Start Bootstrap</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item px-lg-4">
            <a class="nav-link text-uppercase text-expanded" href="<?=base_url('data_antri')?>">Data Antri
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <?php if($this->session->userdata('role_id') == 1 ) { ?>
          <li class="nav-item px-lg-4">
            <a class="nav-link text-uppercase text-expanded" href="<?= base_url('user') ?>">Data User</a>
          </li><?php }?>
          <li class="nav-item px-lg-4">
            <a class="nav-link text-uppercase text-expanded" href="<?=base_url('transaksi')?>">Transaksi</a>
          </li><?php if($this->session->userdata('role_id') == 1 ) { ?>
          <li class="nav-item px-lg-4">
            <a class="nav-link text-uppercase text-expanded" href="<?=base_url('daftar_paket')?>">Daftar Paket</a>
          </li>
          <li class="nav-item px-lg-4">
            <a class="nav-link text-uppercase text-expanded" href="<?=base_url('laporan')?>">Laporan</a>
          </li><?php }if($this->session->userdata('role_id') == 2 ) { ?>
          <li class="nav-item px-lg-4">
            <a class="nav-link text-uppercase text-expanded" href="<?=base_url('ganti_pw')?>">Ganti Password</a>
          </li><?php }?>
          <li class="nav-item px-lg-4">
            <a class="nav-link text-uppercase text-expanded" href="<?=base_url('auth/logout')?>">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<?=$this->session->flashdata('notif')?>
  <?php echo $contents ?>

  <footer class="footer text-faded text-center py-2">
    <div class="container">
      <p class="m-0 small">Copyright &copy; Your Website 2019</p>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?=base_url()?>asset/vendor/jquery/jquery.min.js"></script>
  <script src="<?=base_url()?>asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
   <script>
    function hitung(){
      var total_byr= document.getElementById("total_bayar").value;

      var byr=document.getElementById("bayar").value;

      var byr_b=parseFloat(byr) - parseFloat(total_byr);
      if(!isNaN(byr_b)){
        document.getElementById("kembalian").value=byr_b;
      }
    }
  </script>
 <!--  <script>
  $(document).ready(function(){ // Ketika halaman sudah diload dan siap
    $("#btn-reset-form").click(function(){
      $("#insert-form").html(""); // Kita kosongkan isi dari div insert-form
      $("#jumlah-form").val("1"); // Ubah kembali value jumlah form menjadi 1
    });
  });
  </script> -->
  <script type="text/javascript">  
function changeValuePaket(id){
document.getElementById('prd_harga').value = prdHarga[id].hargam;
};
</script>
<script>
  function printContent(el){
      var restorepage = document.body.innerHTML;
      var printcontent = document.getElementById(el).innerHTML;
      document.body.innerHTML = printcontent;
      window.print();
      document.body.innerHTML = restorepage;
  }
</script>

</body>

</html>
