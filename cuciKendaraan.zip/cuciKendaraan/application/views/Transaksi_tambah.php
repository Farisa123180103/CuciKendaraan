<section class="page-section">
    <div class="container">
      <div class="product-item">
        <div class="product-item-title d-flex">
          <div class="bg-faded p-5 d-flex mx-auto rounded">
            <h2 class="section-heading mb-0">
              <span class="section-heading-lower" style="font-weight:bold">transaksi baru</span>
            </h2>
          </div>
        </div>
        <div class="col-xl-7 d-flex mx-auto">
          <div class="bg-faded p-5 rounded" style="background-color: rgba(230,167,86,.9)">
            
            <?php
             $date = date("Y-m-d");
            foreach($row as $data){ ?>
            <form action="<?= base_url('transaksi/tambah/'.$data->id_data); ?>" method="post" >
              <div class="form-group" >
                <label>No.Nota</label>
                <input type="text" class="form-control" name="nota" readonly="" autocomplete="off" value="<?=$kode;?>" style="width:500px;">
              </div>
              <div class="form-group">
                <label>Tanggal</label>
                <input type="text" class="form-control" name="tgl" readonly="" autocomplete="off" value="<?=$date;?>" >
              </div>
              <div class="form-group">
                  <label >Nama Pelanggan</label>
                  <input type="text" class="form-control" name="nama" readonly="" autocomplete="off" value="<?=$data->nama_pelanggan;?>" >
              </div>
              <div class="form-group">
                  <label >Paket</label>
                  <input type="text" class="form-control" name="paket" readonly="" autocomplete="off" value="<?=$data->nama_paket;?>-<?=$data->harga;?>" >
              </div>
              <div class="form-group">
                  <label >No.Polisi</label>
                  <input class="form-control" name="no_pol" readonly="" autocomplete="off" value="<?=$data->no_pol;?>"  >
              </div>
              <div class="form-group">
                  <label >Total Biaya</label>
                  <input class="form-control" name="total_bayar" id="total_bayar" onkeyup="hitung();" autocomplete="off" readonly="" value="<?=$data->harga;?>"  >
              </div>
              <div class="form-group">
                  <label >Bayar</label>
                  <input class="form-control" type="text" name="bayar" id="bayar" onkeyup="hitung();" required="">
              </div>
              <div class="form-group">
                  <label >Kembalian</label>
                  <input class="form-control" type="text" name="kembalian" id="kembalian"  required="">
              </div>
              <div class="modal-footer">
                  <button class="btn btn-info" name="kirim" type="submit"> Cetak Nota </button>
                  <a class="btn btn-warning" href="<?=base_url('data_antri')?>" data-dismiss="modal"> Batal</a>
              </div>
            </form><?php }?>
          
          </div>
        </div>
      </div>
    </div>
  </section>