<section class="page-section cta">
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <div class="cta-inner rounded">
          	<h1>
			    Rekap Laporan Penghasilan <br>
			    <h5><?=$dari?> sampai <?=$sampai?></h5>
			</h1>
			<div class="col-md-4 ml-auto">
			    <a href="<?=base_url('laporan')?>" class="btn btn-warning btn-flat">Kembali</a>
			    <button onClick="printContent('print')" class="btn btn-primary btn-flat">Print</button>
		    </div>
			
            <!-- <h2 class="section-heading mb-4">
              <span class="section-heading-upper">Our Promise</span>
              <span class="section-heading-lower">To You</span>
            </h2> -->
            <div id="print">
            	<hr align="right" color="rgba(230,167,86,.9)"><br>
            <center>
     
		        <h2>CUCIAN MOBIL LEGUNDI</h2>
		        <h4>Jl. Pulau Legundi, Sukarame, Kec.Sukarame, Kota Bandar Lampung, Lampung</h4><br><br> 
		     
		      </center>
		      <table class="table table-bordered table-striped">
		        <thead>
		          <tr class="bg-info">
		            <th>No.</th>
		            <th>Tanggal</th>
		            <th>No.Nota</th>
		            <th>Nama Pelanggan</th>
		            <th>Paket</th>
		            <th>Total Bayar</th>
		          </tr>
		        </thead>
		        <tbody>
		          <?php 
		          $no=1;
		          foreach($row as $key => $data ) { ?>
		          <tr>
		            <th><?=$no++?></th>
		            <th><?=$data->tgl?></th>
		            <th><?=$data->id_transaksi?></th>
		            <th><?=$data->nama_pelanggan?></th>
		            <th><?=$data->nama_paket?></th>
		            <th>Rp. <?=number_format($data->harga,0,'',',')?></th>
		          </tr>
		          
		          <?php }?>
		        </tbody>
		      </table>
		        <div class="pull-right">
		         <div class="box-body">
		          <div class="row">
		            <div class="col-md-8 ml-auto">
		              <table class="table table-bordered table-striped">
		                <thead>
		                  <tr class="bg-info">
		                    <th>Jumlah Pelanggan</th>
		                    <th>Jumlah Pendapatan</th>
		                  </tr>
		                </thead>
		                <tbody>
		                  
		                  <tr>
		                    <th><?=$no-1?></th>
		                    <th>Rp. <?=number_format($jumlah,0,'',',')?></th>
		                  </tr>
		                </tbody>
		              </table>
		            </div>
		          </div>
		        </div>
		      </div>
		      </div>
          </div>
        </div>
      </div>
    </div>
  </section>
