<section class="page-section cta">
    <div class="container">
      <div class="row">
        <div class="col-xl-20 mx-auto">
          <div class="bg-faded rounded p-5 text-center" style="border: double orange 10px; border-radius: 10px;">
            <h2 class="section-heading mb-4">
              <span class="section-heading-lower">Daftar Transaksi</span>
            </h2>
            <div class="box-body table-responsive">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr class="bg-info">
                    <th>#</th>
                    <th>No.Nota</th>
                    <th>Nama Pelanggan</th>
                    <th>Paket</th>
                    <th>Bayar</th>
                    <th>Kembalian</th>
                    <th>Tanggal</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php if($this->session->userdata('role_id') == 2  ) { 
                    $no=1;
                    $cari=$this->data->user_masuk()->user_id;
                  $row = $this->db->query('SELECT * FROM data_antri d, daftar_paket p, transaksi t WHERE d.id_paket=p.id_paket and t.id_data=d.id_data ORDER BY t.id_transaksi DESC');
                  foreach($row->result() as $key => $data ) { 
                    if($data->user_id==$cari){?>
                  <tr>
                    <th><?=$no++?></th>
                    <th><?=$data->id_transaksi?></th>
                    <th><?=$data->nama_pelanggan?></th>
                    <th><?=$data->nama_paket?>-Rp.<?=$data->harga?></th>
                    <th>Rp.<?=$data->bayar?></th>
                    <th>Rp.<?=$data->kembalian?></th>
                    <th><?=$data->tgl?></th>
                    <th>
                      <center>
                        <div>
                          <a data-toggle="modal" data-target="#modal-edit<?=$data->id_transaksi;?>" class="btn btn-warning" data-popup="tooltip" data-placement="top" title="Nota"><i class="fs fa-pencil"></i>Nota</a>
                        </div>
                      </center>
                    </th> 
                  </tr>
                  <?php }}}else{ 
                  $no=1;
                  $row = $this->db->query('SELECT * FROM data_antri d, daftar_paket p, transaksi t WHERE d.id_paket=p.id_paket and t.id_data=d.id_data ORDER BY t.id_transaksi DESC');
                  foreach($row->result() as $key => $data ) { ?>
                  <tr>
                    <th><?=$no++?></th>
                    <th><?=$data->id_transaksi?></th>
                    <th><?=$data->nama_pelanggan?></th>
                    <th><?=$data->nama_paket?>-Rp.<?=$data->harga?></th>
                    <th>Rp.<?=$data->bayar?></th>
                    <th>Rp.<?=$data->kembalian?></th>
                    <th><?=$data->tgl?></th>
                    <th>
                      <center>
                        <div>
                          <a data-toggle="modal" data-target="#modal-edit<?=$data->id_transaksi;?>" class="btn btn-warning" data-popup="tooltip" data-placement="top" title="Nota"><i class="fs fa-pencil"></i>Nota</a>
                        </div>
                      </center>
                    </th> 
                  </tr>
                  <?php }}?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Model Edit Nota-->
     <?php 
     $row = $this->db->query('SELECT * FROM data_antri d, daftar_paket p, transaksi t WHERE d.id_paket=p.id_paket and t.id_data=d.id_data');
     foreach($row->result() as $key => $data ) {?>
      <div class="row">
        <div id="modal-edit<?=$data->id_transaksi;?>" class="modal fade">
          <div class="modal-dialog">
            <section class="page-section about-heading">
              <div class="container">
                <div class="about-heading-content">
                  <div class="row">
                    <div class="mx-auto">
                      <div class="bg-faded rounded p-5">
                        
                        <div id="printNot">
                        <h2 class="section-heading mb-4">
                          <center>
                          <span class="section-heading-upper" style="font-size: 20pt">CUCIAN MOBIL LEGUNDI</span>
                          <span class="section-heading-lower" style="font-size: 10pt; font-weight:bold;">Jl. Pulau Legundi, Sukarame, Kec.Sukarame, Kota Bandar Lampung, Lampung</span>
                          </center>
                        </h2>
                        <hr align="right" color="rgba(230,167,86,.9)"><br>
                        <table>
                          <tr>
                            <th>Nama Pelanggan </th>
                            <th>: <?=$data->nama_pelanggan;?></th>
                          </tr>
                          <tr>
                            <th>No. Polisi</th>
                            <th>: <?=$data->no_pol;?></th>
                          </tr>
                          <tr>
                            <th>Tanggal</th>
                            <th>: <?=$data->tgl;?></th>
                          </tr>
                          <tr>
                            <th>No. Nota</th>
                            <th>: <?=$data->id_transaksi;?></th>
                          </tr>
                        </table><br>
                        <table class="table table-bordered table-striped">
                          <thead>
                            <tr class="bg-info">
                              <th>Paket</th>
                              <th>Bayar</th>
                              <th>Kembalian</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <th><?=$data->nama_paket?>-Rp.<?=$data->harga?></th>
                              <th>Rp.<?=$data->bayar?></th>
                              <th>Rp.<?=$data->kembalian?></th>
                            </tr>
                          </tbody>
                        </table>
                        <table align="right" class="col-xl-6">
                          <center>
                          <tr align="center">
                            <th>Hormat Kami</th>
                          </tr>
                        </center>
                        </table><br><br><br>
                        <table align="right">
                          <center>
                          <tr>
                            <th>Cuci Kendaraan Legundi</th>
                          </tr></center>
                        </table><br><br>
                        <table align="left">
                          <tr>
                            <th>--------------------Terimakasih--------------------</th>
                          </tr>
                        </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
      <?php } ?>
     <!--END Model Nota-->