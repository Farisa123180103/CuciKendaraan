<section class="page-section clearfix">
    <div class="container">
      <div class="intro">
        <img class="intro-img img-fluid mb-3 mb-lg-0 rounded" src="<?=base_url()?>asset/img/7.jpg" alt="">
        <div class="intro-text left-0  bg-faded p-5 rounded">
          <h2 class="section-heading text-center mb-4">
            <span class="section-heading-upper">Tambah Daftar</span>
            <span class="section-heading-lower">Account User</span>
          </h2>
          <form action="<?php echo base_url('auth/tambah_user')?>" method="post">
            <div class="form-group">
                <label >Nama</label>
                <input type="text" class="form-control" name="nama" placeholder="Masukkan Nama" required>
            </div>
            <div class="form-group">
                <label >Username</label>
                <input type="text" class="form-control" name="uname" placeholder="Masukkan Username" required>
            </div>
            <div class="form-group">
                <label >Password</label>
                <input type="text" class="form-control" name="pw" placeholder="Masukkan Password" required>
            </div>
            <div class="form-group">
                <label >No.Telp</label>
                <input type="text" class="form-control" name="telp" placeholder="Masukkan No.Telp" required>
            </div>
            <div class="form-group">
                <label >Level</label>
                <select class="form-control" name="role_id" required="">
                <option selected="" disabled="">---Pilih Level---</option>
                <?php
                $username = $this->db->query('SELECT * FROM role');
                foreach ($username->result() as $data) { ?>
                  <option value="<?=$data->role_id;?>"><?=$data->level;?></option>
                <?php }?>
              </select>
            </div>
            <div class="intro-button text-center  mx-auto">
              <button class="btn btn-primary btn-xl" type="submit" name="simpan">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
<br><br><br><br><br><br>
  <section class="page-section cta">
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <div class="bg-faded rounded p-5 text-center" style="border: double orange 10px; border-radius: 10px;">
            <h2 class="section-heading mb-4">
              <span class="section-heading-upper">Daftar</span>
              <span class="section-heading-lower">Data User</span>
            </h2>
            <div class="box-body table-responsive">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr class="bg-info">
                    <th>#</th>
                    <th>username</th>
                    <th>nama</th>
                    <th>no_telp</th>
                    <th>level</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                  $no=1;
                  $row = $this->db->query('SELECT * FROM user u, role r WHERE r.role_id=u.role_id');
                  foreach($row->result() as $key => $data ) { ?>
                  <tr>
                    <th><?=$no++?></th>
                    <th><?=$data->username?></th>
                    <th><?=$data->nama?></th>
                    <th><?=$data->no_telp?></th>
                    <th><?=$data->level?></th>
                    <th>
                      <center>
                        <div>
                          <?php if($data->user_id==$this->data->user_masuk()->user_id){ ?>
                          <a data-toggle="modal" data-target="#modal-edit<?=$data->user_id;?>" class="btn btn-warning" data-popup="tooltip" data-placement="top" title="Edit Data"><i class="fs fa-pencil"></i>edit</a>
                          <?php } ?>
                          <a href="<?= base_url('auth/hapus/'.$data->user_id); ?>" onclick="return confirm('Apakah Anda Ingin Menghapus Data <?=$data->username;?> ?');" class="btn btn-danger" data-popup="tooltip" data-placement="top" title="Hapus Data"><i class="fs fa-trash"></i>hapus</a>
                        </div>
                      </center>
                    </th>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Model Edit Data-->
     <?php 
     $row = $this->db->query('SELECT * FROM user u JOIN role r WHERE u.role_id=r.role_id');
     foreach($row->result() as $key => $data ) {?>
      <div class="row">
        <div id="modal-edit<?=$data->user_id;?>" class="modal fade">
          <div class="modal-dialog">
            <form action="<?= base_url('auth/edit/'.$data->user_id); ?>" class="form-horizontal" enctype="multipart/form-data" role="form" method="post">
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <h4 class="modal-title">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <div class="modal-body">
       
                <input type="hidden" readonly value="<?=$data->user_id;?>" name="user_id" class="form-control" >

                <input type="hidden" readonly value="<?=$data->role_id;?>" name="role_id" class="form-control" >

                <div class="form-group">
                    <label>Username</label>
                        <input type="text" class="form-control" name="uname" autocomplete="off" value="<?=$data->username;?>" placeholder="Masukkan username" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                        <input type="passwoard" class="form-control" name="pw" autocomplete="off" value="<?=$data->password;?>" placeholder="Masukkan password" required>
                </div>
                <div class="form-group">
                    <label>Nama Lengkap</label>
                        <input type="text" class="form-control" name="nama" autocomplete="off" value="<?=$data->nama;?>" placeholder="Masukkan nama lengkap" required>
                </div>
                <div class="form-group">
                    <label>No.Telp</label>
                        <input type="text" class="form-control" name="telp" autocomplete="off" value="<?=$data->no_telp;?>" placeholder="Masukkan No. Telp" required>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-info" name="edit" type="submit"> Edit </button>
                    <button type="button" class="btn btn-warning" data-dismiss="modal"> Batal</button>
                </div>
              </div>
            </div>
            </form>
          </div>
        </div>
      </div>
      <?php } ?>
     <!--END Model Edit-->