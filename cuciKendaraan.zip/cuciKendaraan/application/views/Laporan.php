<section class="page-section about-heading">
      <div class="container">
        <img class="img-fluid rounded about-heading-img mb-3 mb-lg-0" src="" alt="">
        <div class="about-heading-content">
          <div class="row">
            <div class="col-xl-6 col-lg-10 mx-auto">
              <div class="bg-faded rounded p-5">
                <h2 class="section-heading mb-4">
                  <span class="section-heading-lower"  style="font-size: 20pt">Rekap</span>
                  <span class="section-heading-upper"  style="font-size: 20pt">Laporan Penghasilan</span>
                </h2>
                  <form action="<?= base_url('laporan/lihat_laporan')?>" method="post">
                    <div class="form-group">
                        <label >Dari Tanggal</label>
                        <input class="form-control" type="date" name="dari" id="dari" value="" placeholder="2020/04/04">
                    </div>
                    <div class="form-group">
                        <label >Sampai Tanggal</label>
                        <input class="form-control" type="date" name="sampai" id="sampai" placeholder="2020/04/04" >
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-info" name="cetak" type="submit"> Cetak </button>
                    </div>
                  </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>