<section class="page-section about-heading">
      <div class="container">
        <img class="img-fluid rounded about-heading-img mb-3 mb-lg-0" src="img/about.jpg" alt="">
        <div class="about-heading-content">
          <div class="row">
            <div class="col-xl-6 col-lg-10 mx-auto">
              <div class="bg-faded rounded p-5">
                <h2 class="section-heading mb-4">
                  <center>
                  <span class="section-heading-upper" style="font-size: 20pt">Ganti Password</span></center>
                </h2>
                  <form action="<?= base_url('ganti_pw/edit/'.$this->data->user_masuk()->user_id)?>" method="post">
                    <input type="hidden" readonly value="<?=$this->data->user_masuk()->user_id;?>" name="user" class="form-control" >
                    <div class="form-group">
                        <label >Password Lama</label>
                        <input class="form-control" type="Password" name="lama" id="lama" value="" placeholder="Masukkan Password Lama" required="">
                    </div>
                    <div class="form-group">
                        <label >Password Baru</label>
                        <input class="form-control" type="Password" name="baru" id="baru" placeholder="Masukkan Password Baru" required="">
                    </div>
                    <div class="form-group">
                        <label >Ulangi Password Baru</label>
                        <input class="form-control" type="Password" name="ulang" id="ulang" placeholder="Ulangi Password Baru" required="">
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-info" name="cetak" type="submit"> Submit </button>
                    </div>
                  </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>