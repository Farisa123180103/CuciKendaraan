<section class="page-section clearfix">
    <div class="container">
      <div class="intro">
        <img class="intro-img img-fluid mb-3 mb-lg-0 rounded" src="<?=base_url()?>asset/img/3.jpg" alt="">
        <div class="intro-text left-0  bg-faded p-5 rounded">
          <h2 class="section-heading text-center mb-4">
            <span class="section-heading-upper">Tambah Daftar</span>
            <span class="section-heading-lower">Paket Baru</span>
          </h2>
          <form action="<?php echo base_url('daftar_paket/tambah')?>" method="post">
            <div class="form-group">
                <label >Nama Paket</label>
                <input type="text" class="form-control" name="nama_paket" placeholder="Tuliskan Nama Paket" required>
            </div>
            <div class="form-group">
                <label >Harga</label>
                <input type="text" class="form-control" name="harga" placeholder="Masukkan Harga" required>
            </div>
            <div class="intro-button text-center  mx-auto">
              <button class="btn btn-primary btn-xl" type="submit" name="simpan">Simpan Paket</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <section class="page-section cta">
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <div class="bg-faded rounded p-5 text-center" style="border: double orange 10px; border-radius: 10px;">
            <h2 class="section-heading mb-4">
              <span class="section-heading-upper">Daftar</span>
              <span class="section-heading-lower">Data Paket</span>
            </h2>
            <div class="box-body table-responsive">
              <table class="table table-bordered table-striped">
                <thead>
                  <tr class="bg-info">
                    <th>#</th>
                    <th>Nama Paket</th>
                    <th>Harga</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                  $no=1;
                  $row = $this->db->query('SELECT * FROM daftar_paket');
                  foreach($row->result() as $key => $data ) { ?>
                  <tr>
                    <th><?=$no++?></th>
                    <th><?=$data->nama_paket?></th>
                    <th><?=$data->harga?></th>
                    <th>
                      <center>
                        <div>
                          <a data-toggle="modal" data-target="#modal-edit<?=$data->id_paket;?>" class="btn btn-warning" data-popup="tooltip" data-placement="top" title="Edit Data"><i class="fs fa-pencil"></i>edit</a>
                          <a href="<?= base_url('daftar_paket/hapus/'.$data->id_paket); ?>" onclick="return confirm('Apakah Anda Ingin Menghapus Paket <?=$data->nama_paket;?> ?');" class="btn btn-danger" data-popup="tooltip" data-placement="top" title="Hapus Data"><i class="fs fa-trash"></i>hapus</a>
                        </div>
                      </center>
                    </th>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Model Edit Data-->
     <?php 
     $row = $this->db->query('SELECT * FROM daftar_paket ');
     foreach($row->result() as $key => $data ) {?>
      <div class="row">
        <div id="modal-edit<?=$data->id_paket;?>" class="modal fade">
          <div class="modal-dialog">
            <form action="<?= base_url('daftar_paket/edit/'.$data->id_paket); ?>" class="form-horizontal" enctype="multipart/form-data" role="form" method="post">
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <h4 class="modal-title">Edit Data</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <div class="modal-body">
       
                <input type="hidden" readonly value="<?=$data->id_paket;?>" name="id_paket" class="form-control" >

                <div class="form-group">
                    <label>Nama Paket</label>
                        <input type="text" class="form-control" name="nama_paket" autocomplete="off" value="<?=$data->nama_paket;?>" placeholder="Tuliskan Nama Paket" required>
                </div>
                <div class="form-group">
                    <label>Harga</label>
                        <input type="text" class="form-control" name="harga" autocomplete="off" value="<?=$data->harga;?>" placeholder="Masukkan Harga Paket" required>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-info" name="edit" type="submit"> Edit </button>
                    <button type="button" class="btn btn-warning" data-dismiss="modal"> Batal</button>
                </div>
              </div>
            </div>
            </form>
          </div>
        </div>
      </div>
      <?php } ?>
     <!--END Model Edit-->